
# -*- coding: utf-8 -*-
import requests, re, os
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

UA = "Mozilla/5.0 (Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117 Mobile Safari/537.36"
TIMEOUT = 20

def is_pdf_url(u): return u.lower().endswith(".pdf")
def is_image_url(u): return any(u.lower().endswith(ext) for ext in [".jpg",".jpeg",".png",".webp",".gif"])

def fetch_html(url):
    r = requests.get(url, headers={"User-Agent": UA}, timeout=TIMEOUT)
    r.raise_for_status()
    return r.text

def extract_text_and_assets(url, html):
    soup = BeautifulSoup(html, "html.parser")
    # Extract text
    for script in soup(["script","style","noscript"]):
        script.extract()
    text = soup.get_text(separator="\n")
    text = re.sub(r"\n{2,}", "\n", text).strip()
    # Collect assets
    links = []
    # PDFs
    for a in soup.find_all("a", href=True):
        u = urljoin(url, a["href"])
        if is_pdf_url(u):
            links.append(("pdf", u))
    # Images
    for imgtag in soup.find_all("img", src=True):
        u = urljoin(url, imgtag["src"])
        if is_image_url(u):
            links.append(("image", u))
    return text, links

def scrape_and_plan_downloads(urls, keyword, cfg, log=lambda *args, **kw: None):
    plan = []
    for url in urls:
        try:
            html = fetch_html(url)
            text, assets = extract_text_and_assets(url, html)
            # Save page text as txt
            plan.append(("text", url, text))
            # PDFs
            if cfg.get("include_pdf", True):
                for t,u in assets:
                    if t=="pdf":
                        plan.append(("pdf", u, None))
            # Images
            if cfg.get("include_images", True):
                for t,u in assets:
                    if t=="image":
                        plan.append(("image", u, None))
            # Video: handled separately by yt-dlp in downloader (we just pass page URL)
            if cfg.get("include_video", True):
                plan.append(("video", url, None))
        except Exception as e:
            log(f"[skip] {url} :: {e}")
    return plan
