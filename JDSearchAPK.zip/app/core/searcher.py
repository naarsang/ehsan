
# -*- coding: utf-8 -*-
import requests, urllib.parse, re

UA = "Mozilla/5.0 (Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117 Mobile Safari/537.36"

def search_duckduckgo(query, max_results=20):
    """Simple HTML-based search to avoid API keys. Returns list of result URLs."""
    q = urllib.parse.quote_plus(query)
    url = f"https://duckduckgo.com/html/?q={q}&kl=wt-wt"
    headers = {"User-Agent": UA}
    r = requests.get(url, headers=headers, timeout=20)
    r.raise_for_status()
    html = r.text
    # Extract results; ddg html returns <a rel="nofollow" class="result__a" href="...">
    links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"', html)
    # Unwrap /l/?kh=1&uddg= encoded URLs
    out = []
    for L in links:
        if "uddg=" in L:
            try:
                import urllib.parse as up
                u = up.parse_qs(up.urlparse(L).query).get("uddg", [""])[0]
                out.append(u)
            except:
                out.append(L)
        else:
            out.append(L)
        if len(out) >= max_results:
            break
    return out
