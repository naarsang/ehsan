
# -*- coding: utf-8 -*-
import os, re, time, threading, subprocess, shlex, requests, pathlib
from urllib.parse import urlparse
from pathlib import Path

BASE_DIR = "/storage/emulated/0/JDSearchDownloads"

def ensure_storage_dir():
    Path(BASE_DIR).mkdir(parents=True, exist_ok=True)

def safe_name(s):
    return re.sub(r'[^A-Za-z0-9_\-\.اآبپتثجچحخدذرزسشصضطظعغفقکگلمنوهی ]+', '_', s)[:120]

class DownloadManager:
    def __init__(self, logger):
        self.logger = logger
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self, plan, keyword, max_mb=200):
        ensure_storage_dir()
        base = Path(BASE_DIR) / safe_name(keyword)
        base.mkdir(parents=True, exist_ok=True)
        used_bytes = 0
        limit_bytes = max_mb * 1024 * 1024

        for kind, url, payload in plan:
            if self._stop: 
                self.logger("⏹ متوقف شد.")
                break
            if used_bytes >= limit_bytes:
                self.logger("⚠️ سقف حجم روزانه پر شد.")
                break
            try:
                if kind == "text":
                    fn = base / (safe_name(urlparse(url).netloc + "_" + Path(urlparse(url).path).name or "page") + ".txt")
                    fn.write_text(payload or "", encoding="utf-8", errors="ignore")
                    self.logger(f"📝 ذخیره متن: {fn.name}")
                elif kind == "pdf":
                    sz = self._download_file(url, base / (safe_name(Path(urlparse(url).path).name) or "file.pdf"))
                    used_bytes += sz
                    self.logger(f"📄 PDF: {url} ({sz//1024} KB)")
                elif kind == "image":
                    ext = Path(urlparse(url).path).suffix or ".jpg"
                    sz = self._download_file(url, base / f"{safe_name(Path(urlparse(url).stem))}{ext}")
                    used_bytes += sz
                    self.logger(f"🖼️ تصویر: {url} ({sz//1024} KB)")
                elif kind == "video":
                    # Use yt-dlp to download best video if supported
                    outtpl = str(base / "%(title).80s.%(ext)s")
                    try:
                        cmd = f"yt-dlp -f best -o {shlex.quote(outtpl)} {shlex.quote(url)}"
                        self.logger(f"🎬 ویدئو: تلاش برای {url}")
                        res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
                        self.logger(res.stdout.decode(errors="ignore")[-500:])
                    except Exception as e:
                        self.logger(f"[video-skip] {e}")
                else:
                    self.logger(f"[unknown] {kind}")
            except Exception as e:
                self.logger(f"[error] {url} :: {e}")

    def _download_file(self, url, dest: Path, chunk=1<<16):
        dest.parent.mkdir(parents=True, exist_ok=True)
        with requests.get(url, stream=True, timeout=30) as r:
            r.raise_for_status()
            sz = 0
            with open(dest, "wb") as f:
                for ch in r.iter_content(chunk_size=chunk):
                    if not ch: 
                        continue
                    f.write(ch)
                    sz += len(ch)
        return sz
