
# -*- coding: utf-8 -*-
import threading, queue, os, time
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty, BooleanProperty
from kivy.clock import Clock
from core.searcher import search_duckduckgo
from core.scraper import scrape_and_plan_downloads
from core.downloader import DownloadManager, ensure_storage_dir

KV = """
<Box@BoxLayout>:
    orientation: "vertical"
    spacing: dp(8)
    padding: dp(12)
    canvas.before:
        Color:
            rgba: (0.06, 0.08, 0.06, 1)
        Rectangle:
            pos: self.pos
            size: self.size

<JDUI>:
    orientation: "vertical"
    padding: dp(10)
    spacing: dp(10)

    BoxLayout:
        size_hint_y: None
        height: dp(42)
        Label:
            text: "JD Search Downloader"
            bold: True
            color: 1,1,1,1
    BoxLayout:
        size_hint_y: None
        height: dp(36)
        TextInput:
            id: keywords
            hint_text: "کلیدواژه‌ها (فارسی/English)"
            multiline: False
            foreground_color: 1,1,1,1
            background_color: 0.08,0.1,0.08,1
            cursor_color: 0.8,0.9,0.8,1
        Button:
            text: "شروع"
            background_color: 0.42,0.56,0.13,1  # olive
            on_release: root.start_search()
    BoxLayout:
        size_hint_y: None
        height: dp(36)
        TextInput:
            id: max_results
            hint_text: "حداکثر نتایج (پیش‌فرض 20)"
            multiline: False
            input_filter: "int"
            foreground_color: 1,1,1,1
            background_color: 0.08,0.1,0.08,1
        TextInput:
            id: max_mb
            hint_text: "سقف حجم روزانه MB (پیش‌فرض 200)"
            multiline: False
            input_filter: "int"
            foreground_color: 1,1,1,1
            background_color: 0.08,0.1,0.08,1
    BoxLayout:
        size_hint_y: None
        height: dp(32)
        CheckBox:
            id: include_video
            active: True
        Label:
            text: "دانلود ویدئو (yt-dlp)"
        CheckBox:
            id: include_pdf
            active: True
        Label:
            text: "دانلود PDF"
        CheckBox:
            id: include_images
            active: True
        Label:
            text: "دانلود تصویر"

    ScrollView:
        do_scroll_x: False
        GridLayout:
            id: logbox
            cols: 1
            size_hint_y: None
            height: self.minimum_height

    BoxLayout:
        size_hint_y: None
        height: dp(40)
        Button:
            text: "توقف"
            on_release: root.stop_downloads()
        Button:
            text: "باز کردن پوشه"
            on_release: root.open_folder()
"""

class JDUI(BoxLayout):
    busy = BooleanProperty(False)
    status = StringProperty("")
    dm = None
    worker = None
    q = queue.Queue()

    def __init__(self, **kw):
        super().__init__(**kw)
        self.dm = DownloadManager(self.log)
        ensure_storage_dir()

    def log(self, msg):
        def _add(*largs):
            from kivy.uix.label import Label
            lb = Label(text=msg, size_hint_y=None, height=22, color=(0.9,0.95,0.9,1))
            self.ids.logbox.add_widget(lb)
        Clock.schedule_once(_add, 0)

    def start_search(self):
        if self.busy: 
            self.log("در حال اجرا...")
            return
        kw = self.ids.keywords.text.strip()
        if not kw:
            self.log("کلیدواژه خالی است.")
            return
        max_results = int(self.ids.max_results.text) if self.ids.max_results.text.strip().isdigit() else 20
        max_mb = int(self.ids.max_mb.text) if self.ids.max_mb.text.strip().isdigit() else 200
        cfg = {
            "include_video": self.ids.include_video.active,
            "include_pdf": self.ids.include_pdf.active,
            "include_images": self.ids.include_images.active,
            "max_results": max_results,
            "max_mb": max_mb,
        }
        self.busy = True
        self.ids.logbox.clear_widgets()
        self.log(f"شروع جستجو برای: {kw}")
        self.worker = threading.Thread(target=self._run, args=(kw, cfg), daemon=True)
        self.worker.start()

    def _run(self, kw, cfg):
        try:
            results = search_duckduckgo(kw, max_results=cfg["max_results"])
            self.log(f"یافت شد: {len(results)} لینک")
            plan = scrape_and_plan_downloads(results, kw, cfg, log=self.log)
            self.log(f"فایل‌های برنامه‌ریزی‌شده: {len(plan)}")
            self.dm.run(plan, kw, max_mb=cfg["max_mb"])
            self.log("پایان.")
        except Exception as e:
            self.log(f"[خطا] {e}")
        finally:
            self.busy = False

    def stop_downloads(self):
        if self.dm:
            self.dm.stop()
            self.log("توقف درخواست شد.")

    def open_folder(self):
        # placeholder: روی اندروید می‌توان SAF یا plyer.filechooser را استفاده کرد
        self.log("پوشه: /storage/emulated/0/JDSearchDownloads")

class JDApp(App):
    def build(self):
        return JDUI()

if __name__ == "__main__":
    Builder.load_string(KV)
    JDApp().run()
