
# JD Search Downloader (Kivy → APK)

## Features
- Keyword search (FA/EN) via DuckDuckGo (HTML)
- Auto-download: page text, images, PDFs, videos (yt-dlp)
- Storage: `/storage/emulated/0/JDSearchDownloads/<keyword>`
- Simple UI (olive theme)

## Build APK (GitHub Actions)
1. Push this folder to a GitHub repo.
2. Add the workflow in `.github/workflows/android.yml`.
3. Go to Actions → run the workflow → download `app/build/outputs/...apk` artifact.

## Build APK (Replit)
- Create Replit (Nix), install buildozer image, or prefer GitHub Actions.

## Notes
- Some sites block scraping. Use proxy/VPN if needed.
- `yt-dlp` may require extra dependencies on Android; in Actions it works.
